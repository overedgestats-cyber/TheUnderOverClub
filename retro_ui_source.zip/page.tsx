﻿import {
  auth,
} from "@clerk/nextjs/server";
import Link from "next/link";

import {
  getConfiguredPlans,
} from "@/lib/stripe/plans";

import styles from "./subscription.module.css";

export const dynamic =
  "force-dynamic";

export default async function SubscriptionPage() {
  const {
    isAuthenticated,
  } =
    await auth();

  let plans:
    Awaited<
      ReturnType<
        typeof getConfiguredPlans
      >
    > = [];

  let configError =
    false;

  try {
    plans =
      await getConfiguredPlans();
  } catch (
    error
  ) {
    configError =
      true;

    console.error(
      "Subscription plan configuration error:",
      error instanceof Error
        ? error.message
        : error,
    );
  }

  return (
    <main className={styles.page}>
      <div className={styles.shell}>
        <Link
          href="/"
          className={styles.brand}
        >
          THE UNDER OVER CLUB
        </Link>

        <section className={styles.hero}>
          <span>
            MEMBERSHIP
          </span>
          <h1>
            Unlock Paid Picks
          </h1>
          <p>
            Every paid option unlocks
            the same Paid Picks. Choose
            only how long you want
            access.
          </p>
        </section>

        {configError ? (
          <div className={styles.notice}>
            Subscription plans are
            temporarily unavailable.
            Please try again shortly.
          </div>
        ) : null}

        {!configError &&
        plans.length === 0 ? (
          <div className={styles.notice}>
            Access plans have not been
            configured yet.
          </div>
        ) : null}

        {plans.length > 0 ? (
          <section className={styles.grid}>
            {plans.map(
              (plan) => (
                <article
                  className={styles.card}
                  key={plan.key}
                >
                  {plan.badge ? (
                    <div className={styles.badge}>
                      {plan.badge}
                    </div>
                  ) : null}

                  <span>
                    {plan.name.toUpperCase()}
                  </span>

                  <h2>
                    {plan.amount ??
                      "Price unavailable"}
                  </h2>

                  <p>
                    {plan.description}
                  </p>

                  {isAuthenticated ? (
                    <form
                      action="/api/billing/checkout"
                      method="post"
                    >
                      <input
                        type="hidden"
                        name="plan"
                        value={plan.key}
                      />

                      <button
                        type="submit"
                      >
                        {plan.key ===
                        "daily"
                          ? "GET DAY PASS"
                          : "SUBSCRIBE"}
                      </button>
                    </form>
                  ) : (
                    <Link
                      className={styles.button}
                      href="/sign-in?redirect_url=/subscription"
                    >
                      SIGN IN TO CONTINUE
                    </Link>
                  )}
                </article>
              ),
            )}
          </section>
        ) : null}
      </div>
    </main>
  );
}
